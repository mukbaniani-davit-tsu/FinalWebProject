<?php
/* ზოგიერთი კონსტანტი */

define("_SALT_PATH", "./.salt");  // "salt string"-ის ფაილი

define('_WEBSITE_ROOT', 'http://localhost:8080/web-project/');


define("_LOGIN_PAGE", _WEBSITE_ROOT . "login.php");  // ავტორიზაციის გვერდი
define("_LOGOUT_PAGE", _WEBSITE_ROOT . "logout.php");  // გასვლის გვერდი
define("_REGISTER_PAGE", _WEBSITE_ROOT . "register.php");  // რეგისტრაციის გვერდი
define("_UPLOAD_PAGE", _WEBSITE_ROOT . "upload.php");  // ფაილის ატვირთვა
define("_EDIT_PAGE", _WEBSITE_ROOT . "edit.php");  // ფაილის რედაქტირება
define("_DELETE_PAGE", _WEBSITE_ROOT . "delete.php");  // ფაილის წაშლა
define("_CONFIRM_EMAIL_PAGE", _WEBSITE_ROOT . "confirm-email.php"); // მეილის დადასტურების გვერდი
define("_FILES_URL", _WEBSITE_ROOT . "files/");

define("_COOKIE_TIME_LIMIT", 30 * 24 * 3600); // დროის ლიმიტი cookie -თვის

/* SQL მონაცემები */
define("_SQL_SERVER", "localhost");
define("_SQL_USERNAME", "test-user");
define("_SQL_PASSWORD", "password123");
define("_SQL_DATABASE", "TestDB");
define("_SQL_SETUP_SCRIPT", "./.setup.sql");

/* ელ-ფოსტის მონაცემები */
define("_EMAIL_HOST", "smtp.gmail.com");
define("_EMAIL_PORT", 587);
define("_EMAIL_SSL", true);
define("_EMAIL_ADDRESS", "uselessfilehosting@gmail.com");
define("_EMAIL_PASSWORD", "&3&^lfvv+692+lo3");

/* ატვირთული ფაილების დირექტორია */
define("_FILE_UPLOAD_DIR", "./files/");
