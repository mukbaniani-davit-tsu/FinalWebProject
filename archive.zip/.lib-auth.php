<?php

require_once("./.lib-constants.php");
require_once("./.lib-common.php");

/* კლასი "Cookie Based" აუთენტიკაციისთვის */
class CookieAuthenticator
{
    private $saltString = null;

    public function __construct()
    {
        $this->saltString = file_get_contents(_SALT_PATH);
    }

    private function _computeProofKey(string $username): string  // ვაგენერირებთ "proof key"-ს (რომელიც "auth key"-ს შემადგენელია)
    {
        $rawData = $username . "." . $this->saltString;
        $hashData = hash("sha256", $rawData);
        return $hashData;
    }

    public function ComputeAuthKey(string $username): string  // ვაგენერირებთ ავტორიზაციის გასაღებს მომხმარებლისთვის
    {
        $proofKey = $this->_computeProofKey($username);
        $authKey = $username . "." . $proofKey;
        return $authKey;
    }

    public function GetAuthUser(string $authKey): string // ვამოწმებთ ავტორიზაციის გასაღების და ვაბრუნებთ შესაბამის მომხმარებელს
    {
        $parts = explode(".", $authKey);
        if (count($parts) !== 2) return null;

        $username = $parts[0];
        $clientProofKey = $parts[1];

        $realProofKey = $this->_computeProofKey($username);
        if ($clientProofKey === $realProofKey)
            return $username;

        return null;
    }
};

class SignInManager
{
    public static function RedirectToLogin(): void  // ვამისამართებთ მომხმარებელს ავროტიზაცია / რეგისტრაციის გვერდზე
    {
        Request::RedirectTo(_LOGIN_PAGE);
    }

    public static function EnsureLoggedIn(): void  // ვამოწმებთ რომ მომხმარებელი ავტორიზებულია
    {
        if (!isset($_COOKIE['auth-key']))
            SignInManager::RedirectToLogin();

        $authenticator = new CookieAuthenticator();
        $user = $authenticator->GetAuthUser($_COOKIE['auth-key']);

        if ($user != null) $GLOBALS['user'] = $user;
        else SignInManager::RedirectToLogin();
    }

    public static function SignIn(string  $username): void
    {
        $authenticator = new CookieAuthenticator();
        $authKey = $authenticator->ComputeAuthKey($username);
        setcookie("auth-key", $authKey);
    }

    public static function SignOut(): void
    {
        setcookie("auth-key", null, 1);
    }
}
