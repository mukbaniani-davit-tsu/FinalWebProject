<?php

require_once("./.lib-constants.php");
require_once("./.lib-common.php");
require_once("./.lib-auth.php");

class DefaultSqlConnection
{
    private static function GetConnection($database = _SQL_DATABASE): mysqli
    {
        $connection = new mysqli(_SQL_SERVER, _SQL_USERNAME, _SQL_PASSWORD, $database);
        if (!$connection) Request::ExitWithError("COULD_NOT_CONNECT_TO_SQL");
        return $connection;
    }

    public static function EnsureInitiated()
    {
        $connection = DefaultSqlConnection::GetConnection(null);
        $script = file_get_contents(_SQL_SETUP_SCRIPT);
        $connection->multi_query($script);
        $connection->close();
    }

    public static function Query(string $query, int $result_mode = MYSQLI_STORE_RESULT)
    {
        $connection = DefaultSqlConnection::GetConnection();
        $result = $connection->query($query, $result_mode);
        if (!$result) Request::ExitWithError("ERROR_EXECUTING_QUERY");
        $connection->close();
        return $result;
    }

    public static function MultiQuery(string $query): bool
    {
        $connection = DefaultSqlConnection::GetConnection();
        $result = $connection->multi_query($query);
        if (!$result) Request::ExitWithError("ERROR_EXECUTING_QUERY");
        $connection->close();
        return $result;
    }
};

class UserManagement
{
    private static function ValidateUsername(string $user): string
    {
        $result = preg_match('/[^a-zA-Z_\-0-9]/i', $user);
        if ($result) return "Username Contains Invalid Characters";

        $users = DefaultSqlConnection::Query("SELECT UserName FROM Users WHERE UserName='$user'");
        if ($users->num_rows > 0) return "Username Already Taken";

        return "";
    }

    private static function ValidatePassword(string $password): string
    {
        $result = preg_match('/[^a-zA-Z_\-0-9]/i', $password);
        if ($result) return "Password Contains Invalid Characters";
        if (strlen($password) < 8) return "Password Is Too Short";
        return "";
    }

    private static function ValidateEmail(string $email): string
    {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return "Email Address Format Is Invalid";

        $emails = DefaultSqlConnection::Query("SELECT UserName FROM Users WHERE EmailAddress='$email'");
        if ($emails->num_rows > 0) return "Email Address Already Taken";

        return "";
    }

    public static function RegisterUser(string $username, string $password, string $email, string $role = 'user'): string
    {
        $usernameValidation = UserManagement::ValidateUsername($username);
        $usernamePassword = UserManagement::ValidatePassword($password);
        $usernameEmail = UserManagement::ValidateEmail($email);

        $errorResult = "";
        if ($usernameValidation !== "") $errorResult .= $usernameValidation . "<br/>";
        if ($usernamePassword !== "") $errorResult .= $usernamePassword . "<br/>";
        if ($usernameEmail !== "") $errorResult .= $usernameEmail . "<br/>";

        if ($errorResult !== "") return $errorResult;

        $emailSecret = EmailVerification::GenetrateEmailSecret();
        if (!EmailVerification::SendConfirmationEmail($username, $email, $emailSecret)) return "Error Sending Verification Email <br/>";

        $passwordHash = hash("sha256", $password);
        $script = "INSERT INTO Users(UserName, PasswordHash, EmailAddress, EmailSecret, Role) 
            VALUES('$username', '$passwordHash', '$email', '$emailSecret', '$role')";
        if (!DefaultSqlConnection::Query($script)) return "Unknown Error Occured <br/>";

        return "";
    }

    public static function VerifyEmail(string $secret): bool
    {
        $query = "SELECT UserName From Users WHERE EmailSecret='$secret'";
        $result = DefaultSqlConnection::Query($query);
        if ($result->num_rows == 0) return false;
        $query = "UPDATE Users SET EmailConfirmed=1 WHERE EmailSecret='$secret'";
        $result = DefaultSqlConnection::Query($query);
        return true;
    }

    public static function CheckLogin(string $username, string $password): string
    {
        $hashed = hash("sha256", $password);
        $result = DefaultSqlConnection::Query(
            "SELECT EmailConfirmed, PasswordHash FROM Users WHERE UserName='$username'"
        );

        if ($result->num_rows === 0) return "Incorrect Username <br/>";

        $row = $result->fetch_row();
        if (!$row[0]) return "Email Not Verified";

        $dbHash = $row[1];
        if ($dbHash !== $hashed) return "Incorrect Password <br/>";

        return "";
    }
};

class FileManagement
{
    public static function UploadFile(string $username, string $title, string $description, array $file): string
    {
        $uid = Random::RandomString(8);
        $query = "INSERT INTO Files(FileId, AuthorUserName, Title, Description) VALUES('$uid', '$username', '$title', '$description')";
        if (!DefaultSqlConnection::Query($query)) return "Couldn't Upload File";

        $targetFile = _FILE_UPLOAD_DIR . $uid . "_" . $file["name"];
        if (!move_uploaded_file($file["tmp_name"], $targetFile)) return "Couldn't Upload File";

        return "";
    }

    public static function GetFileList(string $username): array
    {
        $list = [];
        $owned = DefaultSqlConnection::Query("SELECT FileId FROM Files WHERE AuthorUserName='$username'")->fetch_all();
        foreach ($owned as $file) array_push($list, FileManagement::GetFileInfo($file[0]));
        return $list;
    }

    public static function GetFileInfo(string $fileId, string $username = "admin"): array
    {
        $result = DefaultSqlConnection::Query("SELECT AuthorUserName, Title, Description FROM Files WHERE FileId='$fileId'");
        if ($result->num_rows == 0) return ["Error" => true];
        $row = $result->fetch_row();

        $url = "";
        $files = scandir(_FILE_UPLOAD_DIR);
        foreach ($files as $f)
            if (strpos($f, $fileId) === 0) {
                $url = _FILES_URL . $f;
                break;
            }

        return [
            "id" => $fileId,
            "user" => $row[0],
            "title" => $row[1],
            "description" => $row[2],
            "url" => $url,
            "access" => FileManagement::CheckAccess($fileId, $username)
        ];
    }

    public static function CheckAccess(string $fileId, string $username): bool
    {
        $role = DefaultSqlConnection::Query("SELECT Role FROM Users WHERE UserName='$username'");
        if ($role->num_rows == 0) return false;
        $isAdmin = ($role->fetch_row()[0] == "admin");
        if ($isAdmin) return true;

        $user = DefaultSqlConnection::Query("SELECT AuthorUserName FROM Files WHERE FileId='$fileId'");
        $isUser = ($user->fetch_row()[0] == $username);

        return $isUser;
    }

    public static function EditFile(string $fileId, string $title, string $description): string
    {
        $query = "UPDATE Files SET Title='$title', Description='$description' WHERE FileId='$fileId'";
        if (!DefaultSqlConnection::Query($query)) return "Couldn't Edit File";
        return "";
    }

    public static function DeleteFile(string $fileId): bool
    {
        return (DefaultSqlConnection::Query("DELETE FROM Files WHERE FileId='$fileId'"));
    }
}


DefaultSqlConnection::EnsureInitiated();
