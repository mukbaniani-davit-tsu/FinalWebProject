CREATE DATABASE IF NOT EXISTS TestDB;

USE TestDB;

CREATE TABLE IF NOT EXISTS Users (
	UserName VARCHAR(64) PRIMARY KEY,
	PasswordHash VARCHAR(64) NOT NULL,
	Role ENUM ('admin','user') NOT NULL,
	EmailAddress VARCHAR(64) NOT NULL,
	EmailConfirmed TINYINT DEFAULT 0,
	EmailSecret VARCHAR(64) NULL
);

-- 1:N დამოკიდებულებაშია Users-თან
CREATE TABLE IF NOT EXISTS Files (
	FileId VARCHAR(36) PRIMARY KEY,
	AuthorUserName VARCHAR(64) NOT NULL,
	Title VARCHAR(128) NOT NULL,
	Description VARCHAR(512) NOT NULL
    FOREIGN KEY (AuthorUserName) REFERENCES Users(UserName)
);

-- N:N დამოკიდებულებაშია Users-თან და Files თან
CREATE TABLE IF NOT EXISTS FileSharings (
	TargetFileId VARCHAR(36) NOT NULL,
	TargetUserName VARCHAR(64) NOT NULL,
    FOREIGN KEY (TargetUserName) REFERENCES Users(UserName),
    FOREIGN KEY (TargetFileId) REFERENCES Files(FileId)
);


-- დავამატოთ ადმინები
INSERT IGNORE INTO Users (UserName, PasswordHash, Role, EmailAddress, EmailConfirmed)
	VALUES ('admin', SHA2('admin', 256), 'admin', 'admin@tsu.com', 1);
