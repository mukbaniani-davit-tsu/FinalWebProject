<?php

require_once("./.lib-constants.php");
require_once("./.lib-common.php");
require_once("./.lib-auth.php");
require_once("./.lib-connection.php");

SignInManager::EnsureLoggedIn();
$username = $GLOBALS['user'];

$title = "";
$description = "";
$file = null;

if (isset($_POST['title'])) $title = $_POST['title'];
if (isset($_POST['description'])) $description = $_POST['description'];
if (isset($_FILES['file'])) $file = $_FILES['file'];

$uploadMessage = "";
if ($title !== "" && $description !== "" && $file != null) {
    $uploadMessage = FileManagement::UploadFile($username, $title, $description, $file);
    if ($uploadMessage === "") {
        Request::RedirectTo(_WEBSITE_ROOT);
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload File</title>
    <style>
        form {
            text-align: center;
            font-size: 125%;
            padding: 75px 0px;
        }

        form input {
            font-size: 100%;
            text-align: center;
            padding: 5px;
        }

        form div {
            padding: 5px 0px;
        }

        .red {
            color: red;
        }
    </style>
</head>

<body>

    <form method="POST" action="" enctype="multipart/form-data">
        <div>
        <input id="title" name="title" type="text" placeholder="Title" value="<?php echo ($title); ?>" />
        </div>
        <div>
        <input id="description" name="description" type="text" placeholder="Description" value="<?php echo ($description); ?>" />
        </div>
        <div>
        <input id="file" name="file" type="file" />
        </div>
        <div>
        <input type="submit" value="Upload" />
        </div>
        <?php
        if ($uploadMessage !== "") {
            echo ("<div class='red'>" . $uploadMessage . "</div>");
        }
        ?>
    </form>

    <?php

    ?>
</body>

</html>