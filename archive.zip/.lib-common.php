<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require './PHPMailer/src/Exception.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';


class Request
{
    public static function RedirectTo(string $location): void  // ვამისამართებთ მომხმარებელს სხვა გვერდზე
    {
        die("<script>window.location.href='" . $location . "';</script>");
        #$url = _WEBSITE_ROOT . $location;
        #flush();
        #header("Location: $url");
        #die("Error redirecting to <a href='$url'>$url</a>");
    }
    public static function ExitWithError($message = "UNKNOWN_ERROR_OCCURED")
    {
        die($message);
    }
}

class Random
{
    public static function RandomString($length = 8): string
    {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }
}

class EmailVerification
{
    public static function GenetrateEmailSecret(): string
    {
        return Random::RandomString(64);
    }

    public static function SendConfirmationEmail(string $username, $email, $secret): bool
    {
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true;

        $mail->Host = _EMAIL_HOST;
        $mail->Port = _EMAIL_PORT;
        $mail->Username = _EMAIL_ADDRESS;
        $mail->Password = _EMAIL_PASSWORD;

        $mail->setFrom(_EMAIL_ADDRESS);
        $mail->Subject = "Confirm Your Email";
        $mail->addAddress($email);

        $url = _CONFIRM_EMAIL_PAGE . "?secret=" . $secret;
        $mail->isHTML();
        $mail->Body = "click on the link to confirm your email: <a href='$url'>$url</a>";

        return $mail->send();
    }
}
